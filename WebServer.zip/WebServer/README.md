# Laboratorio 2
## Instrucciones:
## Compilar
$ javac WebClient.java
$ javac WebServer.java

## Correr
En una terminal
$ java WebServer
En una terminal distinta
$ java WebClient
Como ejemplo lo que escribe el WebClient es el path (no mandar espacio)
El WebServer recive y parsea la informacion que esta en la hoja de Laboratorio
Por ultimo el WebServer manda un headerResponse con las variables deseadas